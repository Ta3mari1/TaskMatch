import express from "express";
import bodyParser from "body-parser";
import pg from "pg";


const app = express();
const port = 3000;

app.set('view engine', 'ejs');


//middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));


//Get Home Page

app.get("/", async (req, res) => {
    res.render("homepage", { user: req.user || null });
});






app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
